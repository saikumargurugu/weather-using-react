import './App.css';
import Weather from './modules/weather/weather';

function App() {
  return (
    <div >
      {/* <header className="App-header"> */}
        <Weather />
      {/* </header> */}
    </div>
  );
}

export default App;
